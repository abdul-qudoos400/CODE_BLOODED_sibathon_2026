import sqlite3
from pathlib import Path
from typing import List, Tuple, Optional
import csv
from datetime import datetime

DB_PATH = Path(__file__).parent / "finance_app.db"

def get_conn():
    return sqlite3.connect(DB_PATH)

def init_db():
    with get_conn() as conn:
        cur = conn.cursor()

        cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT
        )
        """)

        cur.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            amount REAL,
            category TEXT,
            note TEXT,
            tdate TEXT
        )
        """)
        conn.commit()

def ensure_user(username: str, password: str) -> None:
    """Create user if not exists (case-insensitive uniqueness)."""
    username_clean = username.strip()
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT username FROM users WHERE LOWER(username)=LOWER(?)", (username_clean,))
        row = cur.fetchone()
        if row:
            return
        cur.execute("INSERT INTO users(username, password) VALUES (?, ?)", (username_clean, password))
        conn.commit()

def validate_login(username: str, password: str) -> Optional[str]:
    """Return canonical username from DB if login OK, else None."""
    u = username.strip()
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute(
            "SELECT username FROM users WHERE LOWER(username)=LOWER(?) AND password=?",
            (u, password),
        )
        row = cur.fetchone()
        return row[0] if row else None

def add_transaction(username: str, amount: float, category: str, note: str, tdate: str) -> None:
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO transactions(username, amount, category, note, tdate) VALUES(?,?,?,?,?)",
            (username, float(amount), category, note, tdate),
        )
        conn.commit()

def get_transactions(username: str) -> List[Tuple]:
    """Returns list of (id, amount, category, note, tdate) for username (case-insensitive)."""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute(
            """
            SELECT id, amount, category, note, tdate
            FROM transactions
            WHERE LOWER(username)=LOWER(?)
            ORDER BY tdate DESC, id DESC
            """,
            (username,),
        )
        return cur.fetchall()

def count_transactions(username: str) -> int:
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM transactions WHERE LOWER(username)=LOWER(?)", (username,))
        return int(cur.fetchone()[0])


def _parse_money(s: str) -> float:
    if s is None:
        return 0.0
    s = str(s).strip()
    if s == "":
        return 0.0
    # Remove common currency symbols and thousands separators
    s = s.replace("$", "").replace("₹", "").replace("Rs.", "").replace("PKR", "")
    s = s.replace(",", "")
    # Handle parentheses for negative amounts like (1,234.56)
    neg = False
    if s.startswith("(") and s.endswith(")"):
        neg = True
        s = s[1:-1]
    try:
        val = float(s)
    except Exception:
        # try to remove any non-digit chars
        filtered = "".join(c for c in s if (c.isdigit() or c in ".-"))
        try:
            val = float(filtered) if filtered else 0.0
        except Exception:
            val = 0.0
    return -val if neg else val


def _normalize_date(s: str) -> str:
    if not s:
        return datetime.today().strftime("%Y-%m-%d")
    s = s.strip()
    # Common formats
    formats = ["%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%m/%d/%Y", "%d.%m.%Y", "%Y/%m/%d"]
    for fmt in formats:
        try:
            return datetime.strptime(s, fmt).strftime("%Y-%m-%d")
        except Exception:
            continue
    # Last resort: try ISO parse
    try:
        return datetime.fromisoformat(s).strftime("%Y-%m-%d")
    except Exception:
        # fallback to raw string
        return s


def import_transactions_from_csv(username: str, csv_path: str) -> int:
    """Import transactions from a CSV file into the DB for `username`.

    Tries to detect common headers (date, amount, debit, credit, description).
    Returns number of rows imported.
    """
    count = 0
    username_clean = username.strip()
    with open(csv_path, newline='', encoding='utf-8-sig') as fh:
        reader = csv.DictReader(fh)
        # Normalize headers
        headers = {h.lower().strip(): h for h in (reader.fieldnames or [])}

        # helper to find best matching header
        def find(*candidates):
            for c in candidates:
                if c in headers:
                    return headers[c]
            return None

        date_h = find('date', 'transaction date', 'posted date', 'value date')
        amount_h = find('amount', 'amt', 'value')
        debit_h = find('debit', 'withdrawal', 'debit amount')
        credit_h = find('credit', 'deposit', 'credit amount')
        desc_h = find('description', 'narration', 'details', 'particulars')

        with get_conn() as conn:
            cur = conn.cursor()
            for row in reader:
                # Get date
                raw_date = (row.get(date_h) if date_h else None) or row.get(next(iter(row), ''), '')
                tdate = _normalize_date(raw_date)

                amount = 0.0
                # Prefer debit/credit columns if present
                if debit_h and row.get(debit_h):
                    amount = _parse_money(row.get(debit_h))
                elif credit_h and row.get(credit_h):
                    # Treat credit as negative (income)
                    amount = -_parse_money(row.get(credit_h))
                elif amount_h and row.get(amount_h):
                    amount = _parse_money(row.get(amount_h))
                else:
                    # try to find a numeric-like field
                    for v in row.values():
                        parsed = _parse_money(v)
                        if parsed != 0.0:
                            amount = parsed
                            break

                note = row.get(desc_h, '') if desc_h else ''
                category = 'Bank'

                cur.execute(
                    "INSERT INTO transactions(username, amount, category, note, tdate) VALUES(?,?,?,?,?)",
                    (username_clean, float(amount), category, note, tdate),
                )
                count += 1
            conn.commit()
    return count